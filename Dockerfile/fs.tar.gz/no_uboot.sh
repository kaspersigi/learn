#!/usr/bin/bash

qemu-system-arm \
	-M vexpress-a9 \
	-m 512M \
	-kernel linux/arch/arm/boot/zImage \
	-dtb linux/arch/arm/boot/dts/arm/vexpress-v2p-ca9.dtb \
	-nographic \
	-append "root=/dev/mmcblk0 rw console=ttyAMA0" \
	-sd rootfs.ext4