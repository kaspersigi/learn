#!/usr/bin/bash

rm -rf filesystem/*
cp -R _fs/* filesystem/
cp -R fs/* filesystem/
mkdir _filesystem
dd if=/dev/zero of=rootfs.ext4 bs=1M count=32
mkfs.ext4 rootfs.ext4
mount -t ext4 rootfs.ext4 _filesystem/ -o loop
cp -R filesystem/* _filesystem
umount _filesystem
rm -rf _filesystem
chown miku:miku rootfs.ext4